<?php
$last_line = system('python C:/xampp/htdocs/pickhacks2019/test.py', $retval);