<html>
<p>
Hello:<?php echo $_POST["0"]; ?>
</html>
